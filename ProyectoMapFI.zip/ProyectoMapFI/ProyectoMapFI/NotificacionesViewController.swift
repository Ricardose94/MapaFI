//
//  NotificacionesViewController.swift
//  ProyectoMapFI
//
//  Created by Usuario invitado on 6/5/19.
//  Copyright © 2019 RS&JR. All rights reserved.
//

import UIKit
import Firebase

class NotificacionesViewController: UIViewController, UITableViewDataSource , UITableViewDelegate {
    
     var noticias = [String]()
    
    @IBOutlet weak var tablaVista: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()
        tablaVista.delegate = self
        tablaVista.dataSource = self
        tablaVista.estimatedRowHeight = 200
       
        Firestore.firestore().collection("Noticias").addSnapshotListener{ (snapshot, error) in
            if let error = error{
                debugPrint(error)
            }else{
                self.noticias.removeAll()
                for document in (snapshot?.documents)!{
                    //print(document.data())
                    let data = document.data()
                    if (data["aviso"] != nil){
                        let resiveNotificacion = data["aviso"] as! String
                        
                        self.noticias.append(resiveNotificacion)
                        
                    }
                    
                }
                
                print(self.noticias)
                
                self.tablaVista.reloadData()
            }
            
        }
        
        
        
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return noticias.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        var cell = tablaVista.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as! CustomTableViewCell
        
        cell.labelCell.text = noticias[indexPath.row]
        return cell
    }

    
}
