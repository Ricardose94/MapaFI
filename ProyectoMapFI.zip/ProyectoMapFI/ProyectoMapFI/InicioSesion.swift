//
//  InicioSesion.swift
//  ProyectoMapFI
//
//  Created by Usuario invitado on 6/5/19.
//  Copyright © 2019 RS&JR. All rights reserved.
//
import UIKit
import Firebase


class InicioSesion: UIViewController {

    @IBOutlet weak var CorreoTextBox: UITextField!
    @IBOutlet weak var ContraseñaTextBox: UITextField!

   
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        
    }
    
    @IBAction func InicioSesion(_ sender: UIButton) {
        
        guard let correo = CorreoTextBox.text,
            let password = ContraseñaTextBox.text else { return }
        
        
        Auth.auth().signIn(withEmail: correo, password: password) { (data, error) in
            if let error = error{
                debugPrint(error.localizedDescription)
            } else {
                self.performSegue(withIdentifier: "VistaMapa", sender: self)
            }
        }
        
        
        
    }
}
