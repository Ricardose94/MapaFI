//
//  RegistroUsuario.swift
//  ProyectoMapFI
//
//  Created by Usuario invitado on 6/5/19.
//  Copyright © 2019 RS&JR. All rights reserved.
//

import UIKit
import Firebase

class RegistroUsuario: UIViewController {

    @IBOutlet weak var CorreoTextBox: UITextField!
    @IBOutlet weak var ContraseñaTextBox1: UITextField!
    @IBOutlet weak var ContraseñaTextBox2: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
    }
    
    
    func salir () {
        dismiss(animated: true, completion: nil)
        
    }
    
    
    @IBAction func registrarse(_ sender: UIButton) {
        
        guard let correo = CorreoTextBox.text , let password1 = ContraseñaTextBox1.text , let password2 = ContraseñaTextBox2.text  else {return}
        
        if (correo != "" && password1 != "" && password2 != "") {
            
            Auth.auth().createUser(withEmail: correo, password: password1) { (data, error) in
                if let error = error{
                    debugPrint(error.localizedDescription)
                }
                
                let user = data?.user
                
                guard let userId = user?.uid else { return }
                
                Firestore.firestore().collection("users").document(userId).setData(["email": correo], completion: { (error) in
                    if let error = error {
                        debugPrint(error)
                    }else{ self.salir() }
                })
            }
            
        }
        
        
    }
    
    @IBAction func cancelar(_ sender: UIButton) {
        salir()
    }
    
}
