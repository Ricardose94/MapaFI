//
//  ViewController.swift
//  ProyectoMapFI
//  
//  Created by Usuario invitado on 6/5/19.
//  Copyright © 2019 RS&JR. All rights reserved.
//

import UIKit
import MapKit
import CoreLocation

class ViewController: UIViewController , CLLocationManagerDelegate, MKMapViewDelegate {

    @IBOutlet weak var mapaView: MKMapView! // Es el objeto mapa
   
    let locationManager = CLLocationManager() //Determina si el usuario tiene habilitados los servicios de localización.Si no se le indicará al usuario la advertencia
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        mapaView.delegate = self // el mapa se hace responsable de si mismo
        
        mapaView.showsUserLocation = true  //La anotación que representa la ubicación del usuario.
        
        
        if (CLLocationManager.locationServicesEnabled() == true){  //Devuelve SÍ  si el dispositivo admite el servicio de lo contrario NO
            
            if(CLLocationManager.authorizationStatus() == .restricted || CLLocationManager.authorizationStatus() == .denied || CLLocationManager.authorizationStatus() == .notDetermined ){
                
                locationManager.requestWhenInUseAuthorization()//Llamar a este método activará un mensaje para solicitar Autorización del usuario.
                
            }
            
            locationManager.desiredAccuracy = 1.0 // Especifica que las actualizaciones de ubicación pueden pausarse automáticamente cuando sea posible.
            locationManager.delegate = self //La determinación de cuándo se pueden pausar automáticamente las actualizaciones de ubicación.
            locationManager.startUpdatingLocation() // activa la funcion locationManager
            
            //            let annotation = PersonalAnnotation()
            //            annotation.coordinate = CLLocationCoordinate2D(latitude: 19.3272, longitude: -99.1829)
            //            annotation.title = "Tienda"
            //            annotation.subtitle = "Don rata"
            //            annotation.imagePin = "tienda"
            //            mapaView.addAnnotation(annotation)
            //
            //            let annotation2 = PersonalAnnotation()
            //            annotation2.coordinate = CLLocationCoordinate2D(latitude: 19.3270, longitude: -99.1829)
            //            annotation2.title = "Laboratorio"
            //            annotation2.subtitle = "Termo"
            //            annotation2.imagePin = "lab"
            //            mapaView.addAnnotation(annotation2)
            
            for i in notaciones{
                let annotation = PersonalAnnotation()
                annotation.coordinate = CLLocationCoordinate2D(latitude: i.latitud, longitude: i.longitud)
                annotation.title = i.title
                annotation.subtitle = i.subtitle
                annotation.imagePin = i.imagen
                
                mapaView.addAnnotation(annotation)
                
                
                
            }
            
            
            
        }else{
            print("Activa tu localizacion")
            
        }
    }
    
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        print(locations[0])
        
        let region = MKCoordinateRegion(center: CLLocationCoordinate2D(latitude: locations[0].coordinate.latitude, longitude: locations[0].coordinate.longitude) , latitudinalMeters: 250 , longitudinalMeters: 250)
        
        self.mapaView.setRegion(region, animated: true)
        
    }
    
    func locationManager(_ manager: CLLocationManager, didFailWithError error: Error) {
        print("no puede acceder a su ubicación actual")
    }
    
    func mapView(_ mapView: MKMapView, viewFor annotation: MKAnnotation) -> MKAnnotationView? {
        //print("funcion")
        if annotation is MKUserLocation{
            
            return nil
        }
        var newAnnotation = mapaView.dequeueReusableAnnotationView(withIdentifier: "PersonalAnnotation")
        if newAnnotation == nil{
            newAnnotation = MKAnnotationView(annotation: annotation, reuseIdentifier: "PersonalAnnotation")
            newAnnotation?.canShowCallout = true
            
            
        }else{
            
            newAnnotation?.annotation = annotation
        }
        
        
        if let newAnnotationView = annotation as? PersonalAnnotation{
            newAnnotation?.image = UIImage(named: newAnnotationView.imagePin)
        }
        return newAnnotation
    }

}

