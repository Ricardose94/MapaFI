//
//  CustomAnnotation.swift
//  ProyectoMapFI
//
//  Created by Usuario invitado on 6/5/19.
//  Copyright © 2019 RS&JR. All rights reserved.
//

import Foundation
import MapKit
class PersonalAnnotation : MKPointAnnotation {
    
    var imagePin : String!
    
}
