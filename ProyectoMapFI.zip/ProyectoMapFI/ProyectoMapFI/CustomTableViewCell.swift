//
//  CustomTableViewCell.swift
//  ProyectoMapFI
//
//  Created by Usuario invitado on 6/5/19.
//  Copyright © 2019 RS&JR. All rights reserved.
//

import UIKit

class CustomTableViewCell: UITableViewCell {

    @IBOutlet weak var labelCell: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
