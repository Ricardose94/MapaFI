//
//  datapin.swift
//  ProyectoMapFI
//
//  Created by Usuario invitado on 6/5/19.
//  Copyright © 2019 RS&JR. All rights reserved.
//

import Foundation
import UIKit

struct pines {
    
    var title: String
    var subtitle: String
    var latitud: Double
    var longitud: Double
    var imagen: String
    
    
}


var notaciones : [pines] = [
    pines(title: "G", subtitle: "Laboratorio de la División de Ciencias Básicas", latitud: 19.3269, longitud: -99.1828, imagen: "lab"),
    pines(title: "H", subtitle: "Laboratorio de la División de Ciencias Básicas", latitud: 19.3270, longitud: -99.1825, imagen: "lab"),
    pines(title: "I", subtitle: "Torre de salones", latitud: 19.3264, longitud: -99.1826, imagen: "salon"),
    pines(title: "J", subtitle: "Ala poniente.Coordinaciones académicas de la DCB", latitud: 19.3263, longitud: -99.1832, imagen: "salon"),
    pines(title: "K", subtitle: "Centro de Docencia Gilberto Borja Navarrete", latitud: 19.3260, longitud: -99.18285, imagen: "salon"),
    pines(title: "L", subtitle: "Biblioteca Enrique Rivero Borrell", latitud: 19.3256, longitud: -99.1826, imagen: "biblioteca"),
    pines(title: "M", subtitle: "Auditorio Sotero Prieto. COPADI(becas, tutorias)", latitud: 19.3260, longitud: -99.1824, imagen: "auditorio"),
    pines(title: "N", subtitle: "Laboratorio de Termofluidos", latitud: 19.32615, longitud: -99.1818, imagen: "lab"),
    pines(title: "N", subtitle: "Laboratorio de Termofluidos", latitud: 19.32655, longitud: -99.1818, imagen: "lab"),
    pines(title: "O - Centro de Diseño Mecánico e Innovación Tecnológica", subtitle: " Laboratorios y talleres de Ingeniería Mecánica", latitud: 19.3270, longitud: -99.1820, imagen: "salon"),
    pines(title: "P", subtitle: "División de Ingeniería Eléctrica", latitud: 19.3277 , longitud: -99.1823, imagen: "salon"),
    pines(title: "Q - Edificio Luis G. Valdés Vallejo.", subtitle: "Laboratorios de Computación,Electrónica y Telecomunicaiones.", latitud: 19.3279, longitud: -99.1820, imagen: "lab"),
    pines(title: "R", subtitle: "División de Ingeniería Civil y Geomática ", latitud: 19.3270, longitud: -99.1813, imagen: "salon"),
    pines(title: "S", subtitle: "Edificio de posgrado", latitud: 19.3276, longitud: -99.1815 , imagen: "salon"),
    pines(title: "T - Edificio Bernardo Quintana Arrioja", subtitle: "Secretarías de Posgrado e Investigacíon y de Apoyo a la Docencia", latitud: 19.3280, longitud: -99.1816 , imagen: "salon"),
    pines(title: "U", subtitle: "Salones para posgrados y tutorías", latitud: 19.3285, longitud: -99.1814, imagen: "salon"),
    pines(title: "V", subtitle: "Laboratorios de posgrado", latitud: 19.3281, longitud: -99.1813, imagen: "lab"),
    pines(title: "W", subtitle: "Biblioteca Enzo Levi", latitud: 19.3285, longitud: -99.1808, imagen: "biblioteca"),
    pines(title: "X - Centro de Ingeniería Avanzada", subtitle: "División de Ingeniería Mecánica e Industrial", latitud: 19.3264, longitud: -99.1815, imagen: "lab"),
    pines(title: "Y", subtitle: "Continucion ala poniente", latitud: 19.3254, longitud: -99.1831, imagen: "salon"),
    pines(title: "1", subtitle: "Auditorio Raúl J. Marsal", latitud: 19.3285, longitud: -99.1811, imagen: "auditorio"),
    pines(title: "2", subtitle: "Jefatura de la División de Ciencias Básicas", latitud: 19.3264, longitud: -99.1830, imagen: "salon"),
    
    
    pines(title: "Tienda", subtitle: "Don rata", latitud: 19.3272, longitud: -99.1829, imagen: "tienda"),
    
    
    
    
    
    pines(title: "A - Edificio de la Dirección, Secretarías General y Administrativa", subtitle: "División de Ciencias Sociales y Humanas , División de Ingenieria en Ciencias de la Tierra", latitud: 19.3314, longitud: -99.1840, imagen: "salon"),
    
    pines(title: "B - Edificio de salones", subtitle: "Edificio de salones", latitud: 19.3310, longitud: -99.1848, imagen: "salon"),
    
    pines(title: "C - Edificio de salones", subtitle: "Laboratorios de Ingenieria Industrial y de Ingenieria en Ciencias de la Tierra", latitud: 19.3312, longitud: -99.18505, imagen: "lab"),
    
    
    pines(title: "D - Edificio de salones", subtitle: "Laboratorios de Ingenieria Eléctrica y de Ingenieria Civil, Servicios Audiovisuales.", latitud: 19.3316, longitud: -99.1847, imagen: "lab"),
    
    pines(title: "E - Edificio UNICA / USECAD", subtitle: "Atención usuarios EDUCAFI, Movilidad Estudiantil, Comunicación", latitud: 19.3314, longitud: -99.1847, imagen: "salon"),
    pines(title: "F", subtitle: "Laboratorios de Ingenieria de Minas y Metalurgia", latitud: 19.3315, longitud: -99.1852, imagen: "lab"),
    
    pines(title: "1", subtitle: "Auditorio Javier Barros Sierra", latitud: 19.3309, longitud: -99.1840, imagen: "auditorio"),
    pines(title: "2", subtitle: "Biblioteca Antonio Dovali Jaime", latitud: 19.3319, longitud: -99.1841, imagen: "biblioteca"),
    pines(title: "3", subtitle: "Aula Magna", latitud: 19.3315, longitud: -99.1851, imagen: "auditorio"),
    pines(title: "4", subtitle: "Sala de Exámenes Profecionales y Sala de consejo Técnico", latitud: 19.3313, longitud: -99.1840, imagen: "auditorio"),
    pines(title: "5", subtitle: "Secretaría de Servicios Académicos", latitud: 19.3315, longitud: -99.1842, imagen: "auditorio"),
    pines(title: "6", subtitle: "Apoyo a la Comunidad (Bolsa de Trabajo, Act. Deportivas)", latitud: 19.3318, longitud: -99.1843, imagen: "salon"),
    pines(title: "7", subtitle: "Coord. de Administración Escolar, Servicios Escolares", latitud: 19.3317, longitud: -99.1843, imagen: "salon")
]

